# 视频解析去水印（Android 工程源码）

一个轻量 Android 应用：粘贴抖音/快手/B站视频或图片的分享链接，解析出**无水印直链**并保存到相册。
也支持配置任意第三方解析接口（自定义 API）。

## 一、构建 APK（两种方式任选）

### 方式 A：Android Studio（推荐，新手友好）
1. 安装 **Android Studio**（Hedgehog 或更新，自带 JDK 与 Gradle）
2. 打开 Android Studio → `File → Open` → 选择本工程根目录（含 `settings.gradle` 的文件夹）
3. 首次打开会自动下载依赖（需联网，等待 Gradle Sync 完成）
4. 菜单 `Build → Build App Bundle(s) / APK(s) → Build APK(s)`
5. 完成后右下角提示 `app/build/outputs/apk/debug/app-debug.apk`，点击 `locate` 即可找到
   - 调试包可直接安装；正式分发请在 `Build → Generate Signed APK` 里生成签名包

### 方式 B：命令行（需本机已有 JDK 17+）
```bash
# 在工程根目录执行（Android Studio 打开过一次后会自动生成 gradlew）
./gradlew assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

## 二、使用说明
1. 打开 App，粘贴从抖音/快手/B站 App 里点"分享"复制的那段文本（带链接的那串）
2. 点"解析"，等待返回标题、封面与直链
3. 点"保存到相册"，文件写入系统相册的 `Movies/VideoParser`（视频）或 `Pictures/VideoParser`（图片）
4. 也可直接在某 App 里"分享 → 选择本应用"，自动带入链接并解析

## 三、自定义解析接口
平台页面结构变动或内置解析失效时，点右上角齿轮：
- 填一个第三方解析服务地址，用 `{url}` 占位待解析链接，例如：
  `https://api.example.com/parse?url={url}`
- 接口必须返回 JSON：
  ```json
  { "code": 0, "title": "标题", "cover": "封面图", "url": "视频无水印直链", "image": "图片直链" }
  ```
  （`url` 与 `image` 至少返回一个；code 非 0 视为失败）

## 四、技术说明与重要声明
- **"去水印"的本质**：解析页面/接口数据里已存在的无水印 CDN 直链，不破解签名、不绕过鉴权、不做视频帧处理。
- 平台接口会随版本变动而失效，属正常现象；本工具不保证长期有效。
- **请仅用于个人学习、收藏与合法用途**，遵守目标平台用户协议与著作权规定；下载他人作品用于商业用途前请取得授权。
- 代码仅使用平台公开页面数据，未实现任何绕过平台防护的破解逻辑。

## 五、工程结构
```
video-parser-app/
├── settings.gradle / build.gradle / gradle.properties
└── app/
    ├── build.gradle                 # AGP 8.1.4 + Kotlin 1.9.22
    └── src/main/
        ├── AndroidManifest.xml      # 权限：仅 INTERNET；支持文本分享接入
        ├── java/com/example/videoparser/
        │   ├── MainActivity.kt      # 界面与交互
        │   ├── VideoParser.kt       # 多平台解析核心（抖音/快手/B站/自定义）
        │   ├── HttpFetcher.kt       # OkHttp 抓取封装
        │   ├── Downloader.kt        # 保存到相册（MediaStore，无需存储权限）
        │   └── ParseResult.kt       # 解析结果模型
        └── res/                     # 布局/主题/图标
```
