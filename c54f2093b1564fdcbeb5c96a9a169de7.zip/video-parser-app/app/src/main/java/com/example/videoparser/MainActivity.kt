package com.example.videoparser

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var input: EditText
    private lateinit var btnParse: Button
    private lateinit var btnSave: Button
    private lateinit var btnSetting: ImageButton
    private lateinit var cover: ImageView
    private lateinit var titleView: TextView
    private lateinit var infoView: TextView
    private lateinit var progress: ProgressBar

    private val scope = CoroutineScope(Dispatchers.Main)
    private var lastResult: ParseResult? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input = findViewById(R.id.input)
        btnParse = findViewById(R.id.btnParse)
        btnSave = findViewById(R.id.btnSave)
        btnSetting = findViewById(R.id.btnSetting)
        cover = findViewById(R.id.cover)
        titleView = findViewById(R.id.title)
        infoView = findViewById(R.id.info)
        progress = findViewById(R.id.progress)

        btnSave.isEnabled = false

        btnParse.setOnClickListener { doParse() }
        btnSave.setOnClickListener { doSave() }
        btnSetting.setOnClickListener { showSettingDialog() }

        // 支持"分享 -> 本应用"直接带入链接
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!text.isNullOrBlank()) {
                input.setText(VideoParser(null).extractUrl(text) ?: text)
                doParse()
            }
        }
    }

    private fun customApi(): String? =
        getSharedPreferences("cfg", MODE_PRIVATE).getString("custom_api", null)?.takeIf { it.isNotBlank() }

    private fun doParse() {
        val text = input.text.toString()
        if (text.isBlank()) { toast("请粘贴视频/图片链接或分享文本"); return }
        btnParse.isEnabled = false
        progress.visibility = ProgressBar.VISIBLE
        titleView.text = "解析中…"
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                VideoParser(HttpFetcher()).parse(text, customApi())
            }
            progress.visibility = ProgressBar.GONE
            btnParse.isEnabled = true
            when (result) {
                is VideoParser.Result.Success -> {
                    lastResult = result.data
                    showResult(result.data)
                }
                is VideoParser.Result.Failure -> {
                    lastResult = null
                    btnSave.isEnabled = false
                    titleView.text = "解析失败"
                    infoView.text = result.reason
                    cover.setImageResource(android.R.drawable.ic_menu_report_image)
                }
            }
        }
    }

    private fun showResult(r: ParseResult) {
        titleView.text = r.title
        infoView.text = buildString {
            append(platformName(r.platform)).append("  ")
            if (r.isVideo) append("视频 · ").append(r.videoUrl?.let { "${it.length / 1024 / 1024}MB" } ?: "")
            else append("图片")
            append("\n").append(if (r.isVideo) r.videoUrl else r.imageUrl)
        }
        btnSave.isEnabled = true
        scope.launch {
            val url = r.coverUrl ?: if (r.isVideo) r.videoUrl else r.imageUrl
            if (url != null) {
                val bmp = withContext(Dispatchers.IO) {
                    try { BitmapFactory.decodeStream(URL(url).openStream()) } catch (e: Exception) { null }
                }
                if (bmp != null) cover.setImageBitmap(bmp)
            }
        }
    }

    private fun platformName(p: String) = when (p) {
        "douyin" -> "抖音"; "kuaishou" -> "快手"; "bilibili" -> "B站"; else -> "自定义"
    }

    private fun doSave() {
        val r = lastResult ?: return
        val target = if (r.isVideo) r.videoUrl else r.imageUrl ?: return
        btnSave.isEnabled = false
        titleView.text = "下载中…"
        scope.launch {
            val uri = try {
                withContext(Dispatchers.IO) { Downloader.save(this@MainActivity, target, r.isVideo) }
            } catch (e: Exception) { null }
            btnSave.isEnabled = true
            if (uri != null) {
                titleView.text = "已保存到相册"
                infoView.text = "位置：${if (r.isVideo) "Movies" else "Pictures"}/VideoParser/"
                toast("保存成功")
            } else {
                titleView.text = "下载失败"
                infoView.text = "网络或直链已失效，可重新解析或更换自定义接口"
            }
        }
    }

    private fun showSettingDialog() {
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val current = prefs.getString("custom_api", "") ?: ""
        val et = EditText(this).apply { setText(current); hint = "如 https://api.example.com/parse?url={url}" }
        AlertDialog.Builder(this)
            .setTitle("自定义解析接口（可选）")
            .setMessage("接口需返回 {\"code\":0,\"title\":\"..\",\"cover\":\"..\",\"url\":\"直链\",\"image\":\"图片直链\"}，{url} 会被替换为待解析链接")
            .setView(et)
            .setPositiveButton("保存") { _, _ ->
                prefs.edit { putString("custom_api", et.text.toString().trim()) }
                toast("已保存")
            }
            .setNegativeButton("清除", null)
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
