package com.example.videoparser

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import okhttp3.Request
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 把无水印直链保存到系统相册（Android 10+ 作用域存储，无需存储权限） */
object Downloader {

    /** 返回保存后的 Uri；失败抛异常 */
    fun save(context: Context, url: String, isVideo: Boolean): Uri {
        val ext = if (isVideo) guessExt(url, "mp4") else guessExt(url, "jpg")
        val fileName = "VideoParser_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "." + ext
        val collection = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                         else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, if (isVideo) "video/mp4" else "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, if (isVideo)
                Environment.DIRECTORY_MOVIES + "/VideoParser" else Environment.DIRECTORY_PICTURES + "/VideoParser")
            if (!isVideo) put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = context.contentResolver.insert(collection, values)
            ?: throw IllegalStateException("无法创建媒体条目")
        try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                val req = Request.Builder().url(url)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) Mobile").build()
                OkHttpHolder.Client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IllegalStateException("下载失败 HTTP ${resp.code}")
                    resp.body?.byteStream()?.copyTo(out)
                }
            } ?: throw IllegalStateException("无法打开输出流")
            if (!isVideo) {
                context.contentResolver.update(uri, ContentValues().apply {
                    put(MediaStore.Images.Media.IS_PENDING, 0)
                }, null, null)
            }
        } catch (e: Exception) {
            context.contentResolver.delete(uri, null, null)
            throw e
        }
        return uri
    }

    private fun guessExt(url: String, fallback: String): String {
        val q = url.substringBefore("?")
        val ext = q.substringAfterLast('.', "")
        return if (ext.length in 2..4 && ext.all { it.isLetter() }) ext.lowercase(Locale.US) else fallback
    }
}
