package com.example.videoparser

import org.json.JSONObject
import java.util.regex.Pattern

/**
 * 视频/图片解析器。
 *
 * 设计说明：
 * 1. 各平台"去水印"的本质是提取页面/接口中已存在的**无水印直链**（CDN 原地址），
 *    本工具不破解签名、不绕过鉴权，只做公开页面数据的解析。
 * 2. 平台页面结构会随版本变动，接口可能失效；失效时可改用"自定义解析接口"
 *    填写第三方解析服务 URL 模板（含 {url} 占位符）。
 * 3. 请仅用于个人学习与收藏，遵守目标平台用户协议与版权规定。
 */
class VideoParser(private val client: HttpFetcher) {

    /** 从任意分享文本中提取第一个 http(s) 链接 */
    fun extractUrl(text: String): String? {
        val m = Pattern.compile("https?://[\\w.-]+(/\\S*)?", Pattern.CASE_INSENSITIVE).matcher(text)
        return if (m.find()) m.group()?.trimEnd('.', '，', ',', '。') else null
    }

    /**
     * 主入口：按域名路由到对应解析器。
     * @param customApi 用户配置的第三方解析接口模板，含 {url}，返回 {code,title,cover,url,type} JSON
     */
    fun parse(input: String, customApi: String?): Result {
        val url = extractUrl(input) ?: return Result.failure("未识别到链接，请粘贴完整分享文本")
        return try {
            val host = url.substringAfter("://").substringBefore("/").lowercase()
            when {
                host.contains("douyin") || host.contains("iesdouyin") -> parseDouyin(url)
                host.contains("kuaishou") || host.contains("gifshow") -> parseKuaishou(url)
                host.contains("bilibili") || host.contains("b23.tv") -> parseBilibili(url)
                !customApi.isNullOrBlank() -> parseCustom(url, customApi)
                else -> Result.failure("暂不支持该平台，可配置自定义解析接口")
            }
        } catch (e: Exception) {
            Result.failure("解析失败：${e.message ?: e.javaClass.simpleName}")
        }
    }

    // ---------------- 抖音 ----------------
    private fun parseDouyin(url: String): Result {
        // v.douyin.com 短链 -> 302 到 www.douyin.com/video/{id}
        val real = client.follow(url)
        // 页面里无水印直链常见字段：playAddr / play_addr / download_addr(带水印)
        val html = client.get(real)
        val title = findInJson(html, "desc", "desc") ?: "抖音视频"
        val videoUrl = findInJson(html, "playAddr", "play_addr") ?: findInJson(html, "uri", "playAddr")
        val cover = findInJson(html, "cover", "cover")
        if (videoUrl == null) return Result.failure("抖音接口可能已变动，请使用自定义解析接口")
        return Result.success(ParseResult("douyin", title, cover, videoUrl))
    }

    // ---------------- 快手 ----------------
    private fun parseKuaishou(url: String): Result {
        // v.kuaishou.com 短链 -> 重定向到 photo 页面，页面 JSON 含 photoUrl(无水印)
        val real = client.follow(url)
        val html = client.get(real)
        val title = findInJson(html, "caption", "caption") ?: "快手视频"
        val videoUrl = findInJson(html, "photoUrl", "mainM3u8s") ?: findInJson(html, "photoH264Url", "photoUrl")
        val cover = findInJson(html, "coverUrl", "coverUrl")
        if (videoUrl == null) return Result.failure("快手接口可能已变动，请使用自定义解析接口")
        return Result.success(ParseResult("kuaishou", title, cover, videoUrl))
    }

    // ---------------- B 站（本身无水印，取清晰度直链） ----------------
    private fun parseBilibili(url: String): Result {
        val real = client.follow(url)
        val bvid = Pattern.compile("(BV[0-9A-Za-z]{10})").matcher(real).takeIf { it.find() }?.group(1)
            ?: return Result.failure("未识别到 B 站视频号")
        val html = client.get(real)
        val title = Pattern.compile("\"title\":\"([^\"]{1,80})\"").matcher(html)
            .takeIf { it.find() }?.group(1)?.replace("\\u0026", "&") ?: "B站视频"
        val cid = Pattern.compile("\"cid\":(\\d+)").matcher(html)
            .takeIf { it.find() }?.group(1) ?: return Result.failure("未找到视频 cid")
        // 公开 playurl 接口（需 Referer 头）
        val api = "https://api.bilibili.com/x/player/playurl?bvid=$bvid&cid=$cid&qn=64&fnval=1"
        val body = client.getWithReferer(api, "https://www.bilibili.com")
        val durl = JSONObject(body).optJSONObject("data")?.optJSONArray("durl")
        val videoUrl = durl?.optJSONObject(0)?.optString("url")
            ?: return Result.failure("B站接口请求失败，可稍后重试")
        return Result.success(ParseResult("bilibili", title, null, videoUrl))
    }

    // ---------------- 自定义解析接口 ----------------
    private fun parseCustom(url: String, template: String): Result {
        val api = template.replace("{url}", java.net.URLEncoder.encode(url, "UTF-8"))
        val body = client.get(api)
        val json = JSONObject(body)
        if (json.optInt("code", 0) != 0) return Result.failure(json.optString("msg", "接口返回异常"))
        val videoUrl = json.optString("url", "").ifBlank { null }
        val imageUrl = json.optString("image", "").ifBlank { null }
        if (videoUrl == null && imageUrl == null) return Result.failure("接口未返回有效直链")
        return Result.success(
            ParseResult("custom", json.optString("title", "解析结果"),
                json.optString("cover", "").ifBlank { null }, videoUrl, imageUrl)
        )
    }

    /** 从 HTML/JSON 文本里按 key 取字符串值（宽容匹配，兼容引号转义） */
    private fun findInJson(html: String, vararg keys: String): String? {
        for (key in keys) {
            // 形如 "key":"value" 或 "key":"http...\\/"（JSON 转义斜杠）
            val p = Pattern.compile("\"$key\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(html)
            if (p.find()) {
                val v = p.group(1).replace("\\/", "/").replace("\\\\", "\\")
                    .replace("\\u0026", "&").replace("\\u003d", "=")
                if (v.startsWith("http")) return v
            }
        }
        return null
    }

    sealed class Result {
        data class Success(val data: ParseResult) : Result()
        data class Failure(val reason: String) : Result()

        companion object {
            fun success(d: ParseResult) = Success(d)
            fun failure(r: String) = Failure(r)
        }
    }
}
