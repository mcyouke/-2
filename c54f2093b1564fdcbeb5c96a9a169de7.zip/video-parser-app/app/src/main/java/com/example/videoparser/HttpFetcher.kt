package com.example.videoparser

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** OkHttp 单例封装：跟随重定向、可带 Referer */
object OkHttpHolder {
    val Client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    class HttpResult(val finalUrl: String, val body: String)
}

/** 用 OkHttp 实现 VideoParser 需要的抓取原语 */
class HttpFetcher(private val client: OkHttpClient = OkHttpHolder.Client) : OkHttpHolder.Client {
    fun get(url: String): String = exec(Request.Builder().url(url).header("User-Agent", UA).build())
    fun getWithReferer(url: String, referer: String): String =
        exec(Request.Builder().url(url).header("User-Agent", UA).header("Referer", referer).build())
    fun follow(url: String): String {
        val resp = client.newCall(Request.Builder().url(url).header("User-Agent", UA).build()).execute()
        resp.use { return it.request.url.toString() }
    }
    private fun exec(req: Request): String {
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
            return resp.body?.string() ?: ""
        }
    }
    companion object { const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36" }
}
