package com.example.videoparser

/** 解析结果：无水印视频直链 / 原图直链 */
data class ParseResult(
    val platform: String,     // douyin / kuaishou / bilibili / custom
    val title: String,
    val coverUrl: String? = null,
    val videoUrl: String? = null,
    val imageUrl: String? = null,
    val durationMs: Long = 0
) {
    val isVideo: Boolean get() = videoUrl != null
}
